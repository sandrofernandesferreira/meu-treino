import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';

export default function HomeScreen() {
  const { user, signOut } = useAuth();
  const [fadeAnim] = useState(new Animated.Value(0));
  const [slideAnim] = useState(new Animated.Value(30));

  useEffect(() => {
    // Animação de entrada
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const firstName = user?.name?.split(' ')[0] || 'Atleta';
  const today = new Date();
  const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  const todayName = weekDays[today.getDay()];

  return (
    <LinearGradient
      colors={['#0D0D1A', '#1A1A2E', '#16213E']}
      style={styles.container}
    >
      <StatusBar barStyle="light-content" backgroundColor="#0D0D1A" />

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.avatarCircle}>
            <Text style={styles.avatarText}>
              {firstName.charAt(0).toUpperCase()}
            </Text>
          </View>
          <TouchableOpacity onPress={signOut} style={styles.signOutBtn}>
            <Text style={styles.signOutText}>Sair</Text>
          </TouchableOpacity>
        </View>

        {/* Mensagem de boas-vindas animada */}
        <Animated.View
          style={[
            styles.welcomeCard,
            { opacity: fadeAnim, transform: [{ translateY: slideAnim }] },
          ]}
        >
          <LinearGradient
            colors={['#FF6B00', '#FF4500']}
            style={styles.welcomeGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <Text style={styles.welcomeEmoji}>💪</Text>
            <Text style={styles.welcomeTitle}>
              Seja bem-vindo ao App que vai te acompanhar durante o seu treino!
            </Text>
            <Text style={styles.welcomeSubtitle}>
              Olá, {firstName}! Hoje é {todayName} — dia de arrasar na academia!
            </Text>
          </LinearGradient>
        </Animated.View>

        {/* Resumo rápido */}
        <View style={styles.statsRow}>
          <StatCard icon="🏋️" label="Treinos" value="0" />
          <StatCard icon="🔥" label="Sequência" value="0 dias" />
          <StatCard icon="⏱️" label="Horas" value="0h" />
        </View>

        {/* Ação principal */}
        <View style={styles.sectionTitle}>
          <Text style={styles.sectionText}>Iniciar treino</Text>
        </View>

        <TouchableOpacity style={styles.startButton} activeOpacity={0.85}>
          <LinearGradient
            colors={['#FF6B00', '#FF4500']}
            style={styles.startGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            <Text style={styles.startIcon}>▶</Text>
            <Text style={styles.startText}>Iniciar Treino de Hoje</Text>
          </LinearGradient>
        </TouchableOpacity>

        {/* Dica do dia */}
        <View style={styles.tipCard}>
          <Text style={styles.tipTitle}>💡 Dica do dia</Text>
          <Text style={styles.tipText}>
            Lembre-se de fazer o aquecimento antes de começar! 5-10 minutos de
            cardio leve ajudam a prevenir lesões e melhorar a performance.
          </Text>
        </View>

        {/* Próximas funcionalidades */}
        <Text style={styles.comingSoon}>Em breve...</Text>
        <View style={styles.featureList}>
          {[
            '📋  Planos de treino personalizados',
            '📈  Gráficos de evolução',
            '⚖️   Controle de peso e medidas',
            '🍎  Dicas de nutrição',
          ].map((f, i) => (
            <View key={i} style={styles.featureItem}>
              <Text style={styles.featureText}>{f}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

function StatCard({ icon, label, value }) {
  return (
    <View style={statCard.container}>
      <Text style={statCard.icon}>{icon}</Text>
      <Text style={statCard.value}>{value}</Text>
      <Text style={statCard.label}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: {
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 30,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  avatarCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#FF6B00',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: '800',
  },
  signOutBtn: {
    paddingVertical: 6,
    paddingHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#FF6B0055',
  },
  signOutText: {
    color: '#FF6B00',
    fontSize: 13,
    fontWeight: '600',
  },
  welcomeCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 20,
    shadowColor: '#FF6B00',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 10,
  },
  welcomeGradient: {
    padding: 22,
  },
  welcomeEmoji: {
    fontSize: 36,
    marginBottom: 8,
  },
  welcomeTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: '#FFFFFF',
    lineHeight: 24,
    marginBottom: 8,
  },
  welcomeSubtitle: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.85)',
    lineHeight: 20,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
    gap: 10,
  },
  sectionTitle: {
    marginBottom: 12,
  },
  sectionText: {
    color: '#8892A4',
    fontSize: 13,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 1.5,
  },
  startButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 20,
    elevation: 6,
    shadowColor: '#FF6B00',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
  },
  startGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    gap: 10,
  },
  startIcon: {
    color: '#FFF',
    fontSize: 16,
  },
  startText: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  tipCard: {
    backgroundColor: 'rgba(255,107,0,0.08)',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,107,0,0.2)',
    marginBottom: 24,
  },
  tipTitle: {
    color: '#FF6B00',
    fontWeight: '700',
    fontSize: 14,
    marginBottom: 8,
  },
  tipText: {
    color: '#8892A4',
    fontSize: 13,
    lineHeight: 20,
  },
  comingSoon: {
    color: '#8892A4',
    fontSize: 13,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 1.5,
    marginBottom: 12,
  },
  featureList: {
    gap: 8,
  },
  featureItem: {
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  featureText: {
    color: '#6B7589',
    fontSize: 13,
    fontWeight: '500',
  },
});

const statCard = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 14,
    padding: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.07)',
  },
  icon: { fontSize: 22, marginBottom: 4 },
  value: { color: '#FFF', fontSize: 16, fontWeight: '800', marginBottom: 2 },
  label: { color: '#8892A4', fontSize: 11, fontWeight: '500' },
});
