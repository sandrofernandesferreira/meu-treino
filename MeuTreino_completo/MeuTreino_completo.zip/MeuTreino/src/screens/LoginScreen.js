import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
  Alert,
  ActivityIndicator,
  StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';

const { width, height } = Dimensions.get('window');

// ⚠️  IMPORTANTE: Substitua pelo seu Web Client ID do Google Cloud Console
// Veja o arquivo README.md para instruções de configuração
const GOOGLE_WEB_CLIENT_ID = 'SEU_WEB_CLIENT_ID_AQUI.apps.googleusercontent.com';

export default function LoginScreen() {
  const { signIn } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      // MODO DESENVOLVIMENTO: login simulado para testar a tela
      // Quando tiver o google-services.json configurado, substitua por login real
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockUser = {
        id: 'user_123',
        name: 'Atleta',
        email: 'atleta@gmail.com',
        photo: null,
        provider: 'google',
      };

      await signIn(mockUser);

      /* ---- LOGIN REAL COM GOOGLE (descomente após configurar google-services.json) ----
      
      import { GoogleSignin } from '@react-native-google-signin/google-signin';
      
      GoogleSignin.configure({
        webClientId: GOOGLE_WEB_CLIENT_ID,
      });

      await GoogleSignin.hasPlayServices();
      const userInfo = await GoogleSignin.signIn();

      const userData = {
        id: userInfo.user.id,
        name: userInfo.user.name,
        email: userInfo.user.email,
        photo: userInfo.user.photo,
        provider: 'google',
      };

      await signIn(userData);
      ---- FIM DO LOGIN REAL ---- */

    } catch (error) {
      Alert.alert('Erro', 'Não foi possível fazer login. Tente novamente.');
      console.log('Erro no login:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient
      colors={['#0D0D1A', '#1A1A2E', '#16213E']}
      style={styles.container}
    >
      <StatusBar barStyle="light-content" backgroundColor="#0D0D1A" />

      {/* Imagem / Ilustração do atleta */}
      <View style={styles.imageContainer}>
        <GymIllustration />
      </View>

      {/* Textos de apresentação */}
      <View style={styles.textContainer}>
        <Text style={styles.appName}>MEU TREINO</Text>
        <View style={styles.divider} />
        <Text style={styles.subtitle}>
          Seu parceiro de{'\n'}musculação
        </Text>
        <Text style={styles.description}>
          Registre seus treinos, acompanhe sua evolução e supere seus limites a cada sessão.
        </Text>
      </View>

      {/* Botão de login */}
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[styles.googleButton, loading && styles.googleButtonDisabled]}
          onPress={handleGoogleLogin}
          activeOpacity={0.85}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#1A1A2E" size="small" />
          ) : (
            <>
              <GoogleIcon />
              <Text style={styles.googleButtonText}>Entrar com o Google</Text>
            </>
          )}
        </TouchableOpacity>

        <Text style={styles.termsText}>
          Ao entrar, você concorda com os{'\n'}
          <Text style={styles.termsLink}>Termos de Uso</Text> e{' '}
          <Text style={styles.termsLink}>Política de Privacidade</Text>
        </Text>
      </View>
    </LinearGradient>
  );
}

// ---- Ícone do Google desenhado em SVG-like com View ----
function GoogleIcon() {
  return (
    <View style={googleIcon.wrapper}>
      <View style={[googleIcon.segment, googleIcon.red]} />
      <View style={[googleIcon.segment, googleIcon.blue]} />
      <View style={[googleIcon.segment, googleIcon.yellow]} />
      <View style={[googleIcon.segment, googleIcon.green]} />
      <View style={googleIcon.center} />
    </View>
  );
}

// ---- Ilustração SVG de academia desenhada com Views ----
function GymIllustration() {
  return (
    <View style={illustration.container}>
      {/* Fundo brilhante */}
      <LinearGradient
        colors={['rgba(255,107,0,0.15)', 'rgba(255,107,0,0)']}
        style={illustration.glow}
      />

      {/* Silhueta do atleta levantando peso */}
      <View style={illustration.scene}>

        {/* Barra de peso */}
        <View style={illustration.barbell}>
          <View style={illustration.plateLeft} />
          <View style={illustration.barbellBar} />
          <View style={illustration.plateRight} />
        </View>

        {/* Braços levantados */}
        <View style={illustration.armsContainer}>
          <View style={illustration.armLeft} />
          <View style={illustration.body} />
          <View style={illustration.armRight} />
        </View>

        {/* Tronco e cabeça */}
        <View style={illustration.torsoContainer}>
          <View style={illustration.head} />
          <View style={illustration.neck} />
          <View style={illustration.torso} />
        </View>

        {/* Pernas */}
        <View style={illustration.legsContainer}>
          <View style={illustration.legLeft} />
          <View style={illustration.legRight} />
        </View>

        {/* Pés */}
        <View style={illustration.feetContainer}>
          <View style={illustration.foot} />
          <View style={[illustration.foot, { marginLeft: 28 }]} />
        </View>
      </View>

      {/* Texto motivacional */}
      <Text style={illustration.motto}>💪 Supere seus limites</Text>
    </View>
  );
}

// ---- Estilos principais ----
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 50,
    paddingHorizontal: 30,
  },
  imageContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  textContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  appName: {
    fontSize: 38,
    fontWeight: '900',
    color: '#FF6B00',
    letterSpacing: 6,
    textShadowColor: 'rgba(255,107,0,0.5)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 12,
  },
  divider: {
    width: 60,
    height: 3,
    backgroundColor: '#FF6B00',
    borderRadius: 2,
    marginVertical: 10,
  },
  subtitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 10,
    lineHeight: 30,
  },
  description: {
    fontSize: 14,
    color: '#8892A4',
    textAlign: 'center',
    lineHeight: 22,
    paddingHorizontal: 10,
  },
  buttonContainer: {
    width: '100%',
    alignItems: 'center',
  },
  googleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 50,
    paddingVertical: 14,
    paddingHorizontal: 28,
    width: '100%',
    shadowColor: '#FF6B00',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
    gap: 12,
  },
  googleButtonDisabled: {
    opacity: 0.7,
  },
  googleButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A2E',
    letterSpacing: 0.5,
  },
  termsText: {
    fontSize: 11,
    color: '#555E6E',
    textAlign: 'center',
    marginTop: 16,
    lineHeight: 18,
  },
  termsLink: {
    color: '#FF6B00',
    fontWeight: '600',
  },
});

// ---- Ícone Google ----
const googleIcon = StyleSheet.create({
  wrapper: {
    width: 22,
    height: 22,
    borderRadius: 11,
    overflow: 'hidden',
    position: 'relative',
  },
  segment: {
    position: 'absolute',
    width: 11,
    height: 11,
  },
  red:    { backgroundColor: '#EA4335', top: 0, left: 0 },
  blue:   { backgroundColor: '#4285F4', top: 0, left: 11 },
  yellow: { backgroundColor: '#FBBC05', top: 11, left: 0 },
  green:  { backgroundColor: '#34A853', top: 11, left: 11 },
  center: {
    position: 'absolute',
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#FFFFFF',
    top: 6,
    left: 6,
  },
});

// ---- Ilustração academia ----
const illustration = StyleSheet.create({
  container: {
    width: width * 0.75,
    height: height * 0.32,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  glow: {
    position: 'absolute',
    width: 200,
    height: 200,
    borderRadius: 100,
    top: 0,
  },
  scene: {
    alignItems: 'center',
    justifyContent: 'flex-end',
    height: '85%',
  },
  // Barra de peso
  barbell: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
  },
  plateLeft: {
    width: 18,
    height: 36,
    backgroundColor: '#FF6B00',
    borderRadius: 4,
    marginRight: 2,
  },
  barbellBar: {
    width: 90,
    height: 10,
    backgroundColor: '#C0C0C0',
    borderRadius: 5,
  },
  plateRight: {
    width: 18,
    height: 36,
    backgroundColor: '#FF6B00',
    borderRadius: 4,
    marginLeft: 2,
  },
  // Braços
  armsContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginTop: -2,
  },
  armLeft: {
    width: 14,
    height: 36,
    backgroundColor: '#E8C49A',
    borderRadius: 7,
    transform: [{ rotate: '-20deg' }],
    marginRight: -2,
  },
  body: {
    width: 10,
    height: 10,
  },
  armRight: {
    width: 14,
    height: 36,
    backgroundColor: '#E8C49A',
    borderRadius: 7,
    transform: [{ rotate: '20deg' }],
    marginLeft: -2,
  },
  // Cabeça e tronco
  torsoContainer: {
    alignItems: 'center',
    marginTop: -4,
  },
  head: {
    width: 28,
    height: 30,
    backgroundColor: '#E8C49A',
    borderRadius: 14,
    marginBottom: 2,
  },
  neck: {
    width: 12,
    height: 8,
    backgroundColor: '#E8C49A',
  },
  torso: {
    width: 44,
    height: 50,
    backgroundColor: '#2A4080',
    borderRadius: 8,
  },
  // Pernas
  legsContainer: {
    flexDirection: 'row',
    gap: 6,
    marginTop: 2,
  },
  legLeft: {
    width: 18,
    height: 44,
    backgroundColor: '#1A1A3E',
    borderRadius: 6,
  },
  legRight: {
    width: 18,
    height: 44,
    backgroundColor: '#1A1A3E',
    borderRadius: 6,
  },
  // Pés
  feetContainer: {
    flexDirection: 'row',
    marginTop: 1,
  },
  foot: {
    width: 20,
    height: 8,
    backgroundColor: '#333',
    borderRadius: 4,
  },
  // Frase
  motto: {
    position: 'absolute',
    bottom: -10,
    color: '#FF6B00',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 1,
  },
});
